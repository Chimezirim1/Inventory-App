import supplierAuthController from "../controllers/supplierAuth.controller.js";
import { Router } from "express";
const router = Router();

router.post("/", supplierAuthController.signUp);
router.post("/login", supplierAuthController.login);

export default router;