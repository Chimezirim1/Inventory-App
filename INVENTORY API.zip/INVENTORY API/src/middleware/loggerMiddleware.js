// loggerMiddleware.js

// Logger middleware function
const logger = (req, res, next) => {
    console.log(`${req.method} ${req.url}`); // Log the HTTP method and URL of the incoming request
    next(); // Continue to the next middleware
};

module.exports = {
    logger
};