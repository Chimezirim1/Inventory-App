function validate(schema) {
return function (req, res, next) {
    const { error, value } = schema.validate(req.body);
    if (error) {
        return res.status(403).send({
            success: false,
            message: error.details[0].message
        })
    }
    req.body = value;
    next();
}
}

export default validate;

































// // validationMiddleware.js

// // Middleware function to validate request body
// const validateRequestBody = (req, res, next) => {
//     // Example validation logic
//     if (req.body && req.body.username && req.body.password) {
//         next(); // Request body is valid, continue to the next middleware
//     } else {
//         res.status(400).json({ message: 'Invalid request body' }); // Invalid request body, return bad request error
//     }
// };

// module.exports = {
//     validateRequestBody
// };