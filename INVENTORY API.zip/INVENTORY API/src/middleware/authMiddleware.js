// authMiddleware.js

// Middleware function to check if a user is authenticated
const isAuthenticated = (req, res, next) => {
    // Check if user is authenticated
    if (req.isAuthenticated()) {
        return next(); // User is authenticated, continue to the next middleware
    } else {
        return res.status(401).json({ message: 'Unauthorized' }); // User is not authenticated, return unauthorized error
    }
};

// Middleware function to check if a user has the necessary role
const hasRole = (role) => {
    return (req, res, next) => {
        // Check if user has the necessary role
        if (req.user && req.user.role === role) {
            return next(); // User has the necessary role, continue to the next middleware
        } else {
            return res.status(403).json({ message: 'Forbidden' }); // User does not have the necessary role, return forbidden error
        }
    };
};

module.exports = {
    isAuthenticated,
    hasRole
};