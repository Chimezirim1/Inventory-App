import SupplierModel from "../models/suppliermodel.js";

// MODEL => SERVICE => CONTROLLER => ROUTE => APP.JS

class SupplierService {
    // creates a new supplier
    async createSupplier(supplier) {
        const newSupplier = await SupplierModel.create(supplier);
        return newSupplier;
    }

    // returns all the suppliers
    async getSuppliers() {
        const suppliers = await SupplierModel.find();
        return suppliers;
    }

    // returns a supplier that matches a query
    async getSupplier(query) {
        const supplier = await SupplierModel.findOne(query);
        return supplier;
    }

    // returns all suppliers that matches a query
    async getAllSupplier(query) {
        const allSuppliers = await SupplierModel.find(query)
        return allSuppliers
    }

    // find a supplier that matches an id
    async getSupplierById(id) {
        const supplier = await SupplierModel.findById(id)
        return supplier;
    }

    // finds a supplier by id and updates it
    async updateSupplier(id, data) {
        const updatedSupplier = await SupplierModel.findByIdAndUpdate(id, data, { new: true })
        return updatedSupplier;
    }

    // find a supplier by id and deletes it
    async deleteSupplierById(id) {
        const deletedSupplier = await SupplierModel.findByIdAndDelete(id)
        return deletedSupplier;
    }
}

export default new SupplierService();