import mongoose from "mongoose";

function connectToMongodb() {
    mongoose.connect("mongodb+srv://oguejicp:ogueji2476@cluster0.4tsibey.mongodb.net/")
    .then(() => {
        console.log("Mongodb is connected");
    })
    .catch(() => {
        console.log("Error connecting to database");
    })
}

export default connectToMongodb;