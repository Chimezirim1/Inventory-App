import express from 'express';
const app = express();
// import connectToMongodb from './configs/database.config.js';
import AuthController from "./controllers/auth.controller.js";
import { Router } from "express";
import connectToMongodb from "./configs/database.config.js";
const router = Router();
import productRouter from "./routes/product.route.js";
import AuthRouter from "./routes/auth.route.js";

app.use("/api/v1/signup", AuthRouter);
app.use("/api/v1/login", AuthRouter);

app.use("/api/v1/products", productRouter);

app.listen(5682, () => {
  connectToMongodb();
  console.log("Server is running on port 5682");
  })