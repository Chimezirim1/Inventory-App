// model/supplierModel.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the supplier schema
const supplierSchema = new Schema({
  supplier_id: { 
    type: String, 
    required: true 
},
  supplier_name: { 
    type: String, 
    required: true
},
  email: { 
    type: String, 
    required: true 
},
  phone_number: { 
    type: String, 
    required: true 
},
  address: { 
    type: String, 
    required: true 
},
});


const supplierModel = new model("supplier", supplierSchema);
export default supplierModel;
// Create a model based on the schema
const Supplier = mongoose.model('Supplier', supplierSchema);

module.exports = Supplier;