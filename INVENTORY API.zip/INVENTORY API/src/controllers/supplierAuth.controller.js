import SupplierService from "../services/supplier.service.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

class AuthController {

    async signUp(req, res) {
        try {
            // Get supplier data from request body
            const supplierData = req.body;

            // Encrypt password
            const salt = await bcrypt.genSalt(10);
            const encryptedPassword = await bcrypt.hash(supplierData.password, salt);

            // Create new supplier
            const newSupplier = await SupplierService.createSupplier({
                ...supplierData, // Include all other supplier data
                password: encryptedPassword 
            });

            // Generate JWT token
            const token = jwt.sign({
                _id: newSupplier._id,
                email: newSupplier.email
            },
                process.env.JWT_SECRET, // Use a secure secret from environment variable
                { expiresIn: '1h' } // Adjust expiration time
            );

            // Set cookie with JWT
            res.cookie('token', token, {
                httpOnly: true,
                maxAge: 3600000 // 1 hour
            });

            // Send success response
            return res.status(201).json({
                success: true,
                message: "Supplier successfully signed up",
                newSupplier // Return the newly created supplier
            });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ message: "Error during signup" });
        }
    }

    async login(req, res) {
        try {
            // Get supplier data from request body
            const supplierData = req.body;

            // Find supplier by email
            const supplier = await SupplierService.getSupplier({ email: supplierData.email });

            // Check if supplier exists
            if (!supplier) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }

            // Compare passwords
            const isValidPassword = await bcrypt.compare(supplierData.password, supplier.password);

            // If passwords don't match
            if (!isValidPassword) {
                return res.status(401).json({ message: 'Invalid credentials' });
            }

            // Generate JWT token
            const token = jwt.sign({
                _id: supplier._id,
                email: supplier.email
            },
                process.env.JWT_SECRET, // Use a secure secret from environment variable
                { expiresIn: '1h' } // Adjust expiration time
            );

            // Set cookie with JWT
            res.cookie('token', token, {
                httpOnly: true,
                maxAge: 3600000 // 1 hour
            });

            // Send success response
            return res.status(200).json({
                success: true,
                message: "Supplier successfully logged in",
                supplier // Return the logged-in supplier
            });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ message: "Error during login" });
        }
    }
}

export default new AuthController();
